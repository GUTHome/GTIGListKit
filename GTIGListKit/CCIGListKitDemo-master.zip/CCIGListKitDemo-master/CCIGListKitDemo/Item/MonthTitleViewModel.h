//
//  MonthTitleViewModel.h
//  CCIGListKitDemo
//
//  Created by dengyouhua on 2018/9/13.
//  Copyright © 2018 cc | ccworld1000@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MonthTitleViewModel : NSObject <IGListDiffable>

- (instancetype)initWithName : (NSString *) name;

@end
