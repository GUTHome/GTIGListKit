[CCIGListKitDemo](https://github.com/ccworld1000/CCIGListKitDemo) is on the way for Objective-C demo

![CCIGListKitDemo](Document/CCIGListKitDemo.gif)
![CCIGListKitDemo MixedDataViewController](Document/MixedDataViewController.png)
![CCIGListKitDemo SearchViewController](Document/SearchViewController.png)
![CCIGListKitDemo SingleSectionViewController](Document/SingleSectionViewController.png)