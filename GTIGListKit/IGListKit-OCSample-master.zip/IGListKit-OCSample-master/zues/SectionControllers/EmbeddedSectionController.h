//
//  EmbeddedSectionController.h
//  zues
//
//  Created by mac on 2017/2/28.
//  Copyright © 2017年 v. All rights reserved.
//

#import <IGListKit/IGListKit.h>

@interface EmbeddedSectionController : IGListSectionController<IGListSectionType>
@property (nonatomic,strong) NSNumber *number;
@end
