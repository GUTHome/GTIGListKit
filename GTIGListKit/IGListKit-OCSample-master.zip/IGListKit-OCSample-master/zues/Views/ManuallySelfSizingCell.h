//
//  ManuallySelfSizingCell.h
//  zues
//
//  Created by mac on 2017/2/28.
//  Copyright © 2017年 v. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManuallySelfSizingCell : UICollectionViewCell
@property (nonatomic,strong) UILabel *label;
@end
