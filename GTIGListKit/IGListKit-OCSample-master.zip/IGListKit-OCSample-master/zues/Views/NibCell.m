//
//  NibCell.m
//  zues
//
//  Created by mac on 2017/3/10.
//  Copyright © 2017年 v. All rights reserved.
//

#import "NibCell.h"

@implementation NibCell
+(NSString *)nibName{
    return @"NibCell";
}
@end
