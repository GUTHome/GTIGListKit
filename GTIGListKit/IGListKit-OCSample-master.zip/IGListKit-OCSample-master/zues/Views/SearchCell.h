//
//  SearchCell.h
//  zues
//
//  Created by v on 17/2/14.
//  Copyright © 2017年 v. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchCell : UICollectionViewCell
/** <#注释#> */
@property (strong, nonatomic) UISearchBar *searchBar;
@end
